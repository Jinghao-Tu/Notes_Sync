#include <asm/segment.h>
#include <errno.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <stdarg.h>
#include <stddef.h>

struct hello_node hello_table[256] = {0};
long hello_pid = -1;
int hello_count = -1;

int sys_init_hello_table()
{
    // printk("Now we're in sys_init_hello_table()\n");
    hello_pid = current->pid;
    push_hello_table(0, "init: hello pid=%d", hello_pid);
    return 0;
}

int sys_print_hello_table()
{
    // printk("Now we're in sys_print_hello_table()\n");
    fprintk(3, "Time\tDesc\n");
    int i;
    for (i = 0; i <= hello_count; i++)
    {
        fprintk(3, "%ld\t%s\n", hello_table[i].time, hello_table[i].description);
    }
    return 0;
}

extern int vsprintf(char *buf, const char *fmt, va_list args);
int push_hello_table(long time, const char *description, ...)
{
    if (hello_count >= 511)
    {
        printk("hello table is full\n");
        return -1;
    }
    hello_count++;
    hello_table[hello_count].time = time;
    
    va_list args;
    va_start(args, description);
    vsprintf(hello_table[hello_count].description, description, args);
    va_end(args);

    return 0;
}
