/*
 * 'kernel.h' contains some often-used function prototypes etc
 */
void verify_area(void * addr,int count);
void panic(const char * str);
int printf(const char * fmt, ...);
int printk(const char * fmt, ...);
int tty_write(unsigned ch,char * buf,int count);
void * malloc(unsigned int size);
void free_s(void * obj, int size);

#define free(x) free_s((x), 0)

/*
 * This is defined as a macro, but at some point this might become a
 * real subroutine that sets a flag if it returns true (to do
 * BSD-style accounting where the process is flagged if it uses root
 * privs).  The implication of this is that you should do normal
 * permissions checks first, and check suser() last.
 */
#define suser() (current->euid == 0)

/* 以下是本实验需要用到的声明 */
int fprintk(int fd, const char * fmt, ...); /* 在 printk.c 中实现 */
struct hello_node {
    long time;
    char description[64];
};
extern struct hello_node hello_table[256];  /* 在 hellohit.c 中定义 */
extern long hello_pid;  /* 在 hellohit.c 中定义 */
extern int hello_count; /* 在 hellohit.c 中定义 */
/* sys_init_hello_table() 和 sys_print_hello_table() 两个作为系统调用在 sys.h 和 unistd.h 中声明 */
extern int push_hello_table(long time, const char * description, ...);

/** 修改的文件列表, 准备部分
 * 1. kernel/hellohit.c
 * 2. kernel/printk.c
 * 3. init/main.c
 * 4. include/linux/kernel.h
 * 5. include/linux/sys.h
 * 6. include/unistd.h
 * 7. kernel/Makefile
 * 8. kernel/system_call.s
*/

/** 进程管理部分
 * 1. kernel/fork.c 不处理, 因为要先 fork() 之后再开始跟踪
 * 2. fs/exec.c 作为跟踪的起点, 在 do_execve() 中添加
 * 3. kernel/exit.c 作为跟踪的终点, 在 do_exit() 中添加
 * 4. kernel/sched.c 需要跟踪
*/

/** 块设备部分 (因为 hello 程序保存在硬盘中, 所以我们先只考虑硬盘)
 * 1. kernel/blk_drv/ll_rw_blk.c 是所有块设备的通用驱动程序
 *  ll_rw_block() 用于创建请求项并将其插入请求队列中, 函数链是 ll_rw_block() -> make_request() -> add_request()
 *  dev->request_fn() 用于处理请求项, 与设备相关
 * 2. kernel/blk_drv/hd.c 用于向硬盘控制器发出读写中断, 也就是实际的读写操作发生在这里
 *  这里有 do_hd_request(), read_intr(), write_intr() 三个主要的函数
 *  它们的意义分别是向硬盘控制器发出读写请求, 控制器完成读写后会发出相应的中断信号; 处理读中断; 处理写中断
 *  这里不用跟踪, 因为读写请求的处理与当前进程无关.
*/

/** I/O 部分 - printf
 * 1. 根据 gcc 编译出的汇编代码, 对 _printf 进行跟踪. 可以在 init/main.c 中找到 printf()
 *  main.c 的 include 中并未包含 kernel.h, 随意添加会对内核造成影响 :)
 *  这里多加了两个判断条件, 目的是安全运行. tty 也相同.
 *  问题在于汇编中的 call _printf 似乎不是这里的 printf()
 *  Good News! Everyone! 这里的 printf() 是 stdio.h 中的,
 *  在 linux-0.11 的硬盘文件中, /usr/include/stdio.h 中有 printf() 的声明
 *  那么就放弃对 printf() 的跟踪吧, 但是还是要跟踪 tty_write()
*/

/** 字符设备部分
 * 这里我们主要考虑 tty 相关代码, 因为 hello 程序的输出是通过 tty 设备的
 * 1. kernel/chr_dev/console.c 控制终端显示屏, 在这里可以跟踪 hello 字符串的输出. con_write()
 * 2. kernel/chr_dev/tty_io.c 用于处理字符设备的读写, 这里主要是 tty_write() 要跟踪
 *  安全需求同 printf() :)
*/

/** 缓冲部分
 * fs/buffer.c
 * 1. get_blk()
 * 2. brelse()
 * 3. bread()
 * 4. bread_page()
 * 5. breada()
 * 以上是 buffer.c 中主要用到的函数
*/

/** 内存部分
 * 1. fs/exec.c 中加载可执行文件到内存中, 并将进程跳转到目标代码段去执行.
 *  这里会得到 m_inode, 这是内存中的 i 节点.
 *  以下是来自 《注释》 的解释:
 *  首先执行对参数和环境参数空间页面的初始化;
 *  然后根据执行文件开始部分的头数据结构, 对其中信息进行处理;
 *  对当前调用进程进行运行新文件前初始化操作;
 *  最后替换堆栈上原调用 execve(), 程序的返回地址为新执行程序地址, 运行新加载的程序.
*/
